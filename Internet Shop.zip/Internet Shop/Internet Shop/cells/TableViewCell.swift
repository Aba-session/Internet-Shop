//
//  TableViewCell.swift
//  Internet Shop
//
//  Created by Admin on 07.02.2021.
//

import UIKit

class TableViewCell: UITableViewCell {
    static let identifider = String(describing: TableViewCell.self)
    static let nib = UINib(nibName: identifider, bundle: nil)
    var item = Product(name: nil, descr: nil, cost: nil, imageName: nil)
    
    @IBOutlet weak var productImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var addButton: UIButton!
    
    
    @IBAction func addToCart(_ sender: Any) {
        CartSingltone.shared.addToCart(item)
    }
    
    func configure(_ item: Product) {
        addButton.layer.cornerRadius = addButton.frame.size
            .height/4
        self.item = item
        productImageView.image = UIImage(named: item.imageName ?? "eror image name")
        nameLabel.text = item.name
        descriptionLabel.text = item.descr
        priceLabel.text = String(item.cost ?? 0.0)+"$"
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
