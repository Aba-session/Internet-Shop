//
//  ViewController.swift
//  Internet Shop
//
//  Created by Admin on 06.02.2021.
//

import UIKit

class ViewController: UIViewController {
    static let identifier = String(describing: ViewController.self)
    static let nib = UINib(nibName: identifier, bundle: nil)
    
    var productArray = [Product]()
    @IBOutlet weak var shopTableView: UITableView!
    @IBOutlet weak var shopCollectionView: UICollectionView!
    @IBOutlet weak var viewSegmentedController:UISegmentedControl!
    @IBOutlet weak var cartButton: UIBarButtonItem!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        productArrayConfigure()
        shopTableConfigure()
        shopCollectionConfigure()
    }
    @IBAction func showCart(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(identifier: CartViewController.identifier) as! CartViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func switchView(_ sender: UISegmentedControl) {
        if shopTableView.isHidden {
                shopTableView.isHidden = false
                shopCollectionView.isHidden = true
            } else {
                shopTableView.isHidden = true
                shopCollectionView.isHidden = false
            }
    }
    
    func shopTableConfigure(){
        shopTableView.backgroundColor = .systemGray6
        shopTableView.delegate = self
        shopTableView.dataSource = self
        shopTableView.register(TableViewCell.nib, forCellReuseIdentifier: TableViewCell.identifider)
    }
    
    func shopCollectionConfigure(){
        shopCollectionView.backgroundColor = .systemGray6
        shopCollectionView.delegate = self
        shopCollectionView.dataSource = self
        shopCollectionView.register(CollectionViewCell.nib, forCellWithReuseIdentifier: CollectionViewCell.identifier)
    }
    

    
    func productArrayConfigure() {
        self.productArray.append(Product(name: "Something1", descr: "something", cost: 00 , imageName: ""))
        self.productArray.append(Product(name: "Something2", descr: "Something122", cost: 00 , imageName: ""))
        self.productArray.append(Product(name: "Something3", descr: "Something1123213", cost: 0 , imageName: ""))
        self.productArray.append(Product(name: "Something4", descr: "Something11321231321", cost: 00, imageName: ""))
        self.productArray.append(Product(name: "Something5", descr: "Something121321", cost: 00, imageName: ""))
        self.productArray.append(Product(name: "Something6", descr: "Something1456456", cost: 00, imageName: ""))
        self.productArray.append(Product(name: "Something7", descr: "Something14566", cost: 00, imageName: ""))
        self.productArray.append(Product(name: "Something8", descr: "Something1123231", cost: 00, imageName: ""))
    }
}

extension ViewController: UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.productArray.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = shopTableView.dequeueReusableCell(withIdentifier: TableViewCell.identifider) as! TableViewCell
        cell.configure(self.productArray[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(identifier: ProductViewController.identifider) as! ProductViewController
        vc.item = self.productArray[indexPath.row]
        navigationController?.pushViewController(vc, animated: true)
    }
}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.productArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell =
            shopCollectionView.dequeueReusableCell(withReuseIdentifier: CollectionViewCell.identifier, for: indexPath) as! CollectionViewCell
        cell.configure(self.productArray[indexPath.item])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(identifier: ProductViewController.identifider) as! ProductViewController
        vc.item = self.productArray[indexPath.item]
        navigationController?.pushViewController(vc, animated: true)
    }
}
